package portfolio.keypang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeypangApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeypangApplication.class, args);
	}

}
